chmod +x run.sh
./run.sh